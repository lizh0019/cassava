# Analysis

This directory contains the code used for the VAE and mutual information experiments from the paper.
